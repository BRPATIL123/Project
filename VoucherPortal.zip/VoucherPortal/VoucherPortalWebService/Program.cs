using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using VoucherPortalDataAccessLayer;
using VoucherPortalDataAccessLayer.Interface;
using VoucherPortalDataAccessLayer.Models;
using VoucherPortalWebService.Extensions;

var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;

// Add services to the container.


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
// Add services to the container.
// Connection String / DbContext

var connectionString = configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<VoucherPortalDBContext>(
    options => options.UseSqlServer(connectionString)
);
// Dapper
builder.Services.AddScoped<IDbConnection>(
    sp => new SqlConnection(connectionString)
);
builder.Services.AddScoped<IAdminRepository, AdminRepository>();
builder.Services.AddScoped<ICustomerRepository, CustomerRepository>();
builder.Services.AddHttpContextAccessor();
// Controllers
builder.Services.AddControllers();
builder.Services.AddRepositories();
builder.Logging.AddConsole();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
