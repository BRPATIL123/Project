﻿using VoucherPortalDataAccessLayer;
using VoucherPortalDataAccessLayer.Interface;

namespace VoucherPortalWebService.Extensions
{
    public static class VoucherPortalExtensions
    {
        public static void AddRepositories(this IServiceCollection services)
        {
            // User
            services.AddScoped<IAdminRepository, AdminRepository>();

        }
    }
}
