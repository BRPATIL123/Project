﻿namespace VoucherPortalWebService.Models
{
    public class Certification
    {
        public string CertCode { get; set; }
        public string CertName { get; set; }
        public string CertType { get; set; }
        public int? CertCreditPoints { get; set; }
    }
}
