﻿using Microsoft.EntityFrameworkCore;

namespace VoucherPortalWebService.Models
{
    public class VoucherPortalDBContext : DbContext
    {
        public DbSet<Certification> Users { get; set; }

        public VoucherPortalDBContext(DbContextOptions<VoucherPortalDBContext> options) : base(options)
        { }
    }
}
