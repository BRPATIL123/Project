﻿using Microsoft.AspNetCore.Mvc;
using VoucherPortalDataAccessLayer.Interface;

namespace VoucherPortalWebService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : Controller
    {
        private ILogger<CustomerController> _logger;
        private readonly IConfiguration _configuration;
        private readonly ICustomerRepository _customerRepository;
        public CustomerController(ICustomerRepository customerRepository, IConfiguration configuration, ILogger<CustomerController> logger)
        {
            _configuration = configuration;
            _logger = logger;
            _customerRepository = customerRepository;
        }
        [HttpDelete("DeleteRequest/{requestId}")]
        public IActionResult DeleteRequest(int requestId)
        {
            try
            {
                var result = _customerRepository.DeleteRequest(requestId);
                if (result)
                {
                    return Ok("Request deleted successfully.");
                }
                return NotFound("Request not found.");
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet("GetRequestDetail/{requestId}")]
        public IActionResult GetRequestDetail(int requestId)
        {
            try
            {
                var requestDetail = _customerRepository.GetRequestDetail(requestId);
                if (requestDetail != null)
                {
                    return Ok(requestDetail);
                }
                return NotFound("Request detail not found.");
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost("InsertVoucherRequest")]
        public IActionResult InsertVoucherRequest(int empNumber, string certCode)
        {
            try
            {
                int requestId;
                var result = _customerRepository.InsertVoucherRequest(empNumber, certCode, out requestId);
                if (result >= 0)
                {
                    return Ok(new { Message = "Voucher request inserted successfully.", RequestId = requestId });
                }
                return BadRequest("Failed to insert voucher request.");
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPut("UpdateScore/{requestId}")]
        public IActionResult UpdateScore(int requestId, int score)
        {
            try
            {
                var result = _customerRepository.UpdateScore(requestId, score);
                if (result)
                {
                    return Ok("Score updated successfully.");
                }
                return NotFound("Request not found.");
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
