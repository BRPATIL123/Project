﻿using Microsoft.AspNetCore.Mvc;
using VoucherPortalDataAccessLayer.Interface;
using VoucherPortalDataAccessLayer.Models;

namespace VoucherPortalWebService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AdminController : Controller
    {
        private ILogger<AdminController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IAdminRepository _adminRepository;

        public AdminController(IConfiguration configuration, IAdminRepository adminRepository, ILogger<AdminController> logger)
        {
            _configuration = configuration;
            _adminRepository = adminRepository;
            _logger = logger;
        }

        [HttpGet("GetByType")]
        public ActionResult<List<Certification>> GetCertificationsOnCertType(string certType)
        {
            return _adminRepository.GetCertificationsOnCertType(certType);
        }

        [HttpPost("Add")]
        public ActionResult<bool> AddCertification(Certification certification)
        {
            return _adminRepository.AddCertification(certification);
        }

        [HttpPost("UpdateCreditPoints")]
        public ActionResult<bool> UpdateCreditPoints(string certCode, int credPoints)
        {
            try
            {
                var result = _adminRepository.UpdateCreditPoints(certCode, credPoints);
                if (result)
                {
                    return Ok(true);
                }
                return BadRequest(false);
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return StatusCode(500, false);
            }
        }
        [HttpPost("UpdateVoucherID")]
        public ActionResult<bool> UpdateVoucherID(int requestID)
        {
            try
            {
                var result = _adminRepository.UpdateVoucherID(requestID);
                if (result)
                {
                    return Ok(true);
                }
                return BadRequest(false);
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return StatusCode(500, false);
            }
        }

    }
}
