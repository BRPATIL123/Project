﻿using VoucherPortalDataAccessLayer;
using VoucherPortalDataAccessLayer.Models;

namespace VoucherPortalConsoleApp
{
    public class Program
    {

        static VoucherPortalDBContext context;
        static AdminRepository adminRepository;
        static CustomerRepository customerRepository;

        static Program()
        {
            context = new VoucherPortalDBContext();
            adminRepository = new AdminRepository(context);
            customerRepository = new CustomerRepository(context);
        }

        //static void TestInsertVoucherRequest()
        //{

        //    int requestId;
        //    int returnValue = customerRepository.InsertVoucherRequest(1009, "EX-001", out requestId);
        //    if (returnValue == 1)
        //    {
        //        Console.WriteLine("Your voucher request is successful!");
        //        Console.WriteLine("The Request ID is " + requestId.ToString());
        //    }
        //    else if (returnValue == -1)
        //        Console.WriteLine("Employee ID doesnt exist!");

        //    else if (returnValue == -2)
        //        Console.WriteLine("Employee already requested Voucher for same Certification code!");

        //    else
        //        Console.WriteLine("Some error occurred!");

        //}


        //static void TestGetCertificationsOnCertType()
        //{
        //    var certification = adminRepository.GetCertificationsOnCertType("E");
        //    Console.WriteLine("----------------------------------");
        //    Console.WriteLine("CertificationCode\tCertificationName");
        //    Console.WriteLine("----------------------------------");
        //    foreach (var cert in certification)
        //    {
        //        Console.WriteLine("{0}\t\t\t{1}", cert.CertCode, cert.CertName);
        //    }
        //}


        //static void TestUpdateVoucherId()
        //{

        //    bool returnValue = adminRepository.UpdateVoucherID(5000);
        //    if (returnValue)
        //    {
        //        Console.WriteLine("Voucher ID updated successfully");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Error while updating voucher ID");
        //    }

        //}

        //static void TestAddCertification()
        //{
        //    Certification newCertification = new Certification();
        //    newCertification.CertCode = "EX-006";
        //    newCertification.CertName = "DSA";
        //    newCertification.CertType = "E";
        //    newCertification.CertCreditPoints = 6;
        //    bool status = adminRepository.AddCertification(newCertification);
        //    if (status)
        //    {
        //        Console.WriteLine("Certification added successfully");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Error while adding certification");
        //    }
        //}


        //static void TestUpdateCreditPoints()
        //{
        //    string certCode = "IN-004";
        //    int creditPoints = 15;
        //    bool status = adminRepository.UpdateCreditPoints(certCode, creditPoints);
        //    if (status)
        //    {
        //        Console.WriteLine("Credit points updated successfully");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Error while updating credit points");
        //    }
        //}


        static void TestUpdateScore()
        {
            bool returnValue = customerRepository.UpdateScore(5002, 80);
            if (returnValue)
            {
                Console.WriteLine("Score updated successfully");
            }
            else
            {
                Console.WriteLine("Error while updating score");
            }

        }

        //static void TestDeleteRequest()
        //{
        //    bool returnValue = customerRepository.DeleteRequest(5003);
        //    if (returnValue)
        //    {
        //        Console.WriteLine("Request deleted successfully");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Error while deleting request");
        //    }

        //}

        //static void TestGetRequestDetails()
        //{
        //    var request = customerRepository.GetRequestDetail(5002);
        //    Console.WriteLine("----------------------------------");
        //    Console.WriteLine("CertificationCode\tDateOfRequest\t\t\tScore");
        //    Console.WriteLine("----------------------------------");
        //    Console.WriteLine("{0}\t\t\t{1}\t\t{2}", request.CertCode, request.DateOfRequest, request.Score);
        //}
        static void Main(string[] args)
        {
            /* Admin Functionalities */
            //TestGetCertificationsOnCertType();
            //TestAddCertification();
            //TestUpdateCreditPoints();
            //TestUpdateVoucherId();

            /* Customer Functionalities */
            //TestInsertVoucherRequest();
            TestUpdateScore();
            //TestDeleteRequest();
            //TestGetRequestDetails();

        }
    }
}