﻿using VoucherPortalDataAccessLayer.Interface;
using VoucherPortalDataAccessLayer.Models;

namespace VoucherPortalDataAccessLayer
{
    public class AdminRepository : IAdminRepository
    {
        private readonly VoucherPortalDBContext _voucherDBContext;

        public AdminRepository(VoucherPortalDBContext voucherDBContext)
        {
            _voucherDBContext = voucherDBContext;
        }

        public bool AddCertification(Certification certification)
        {
            try
            {
                _voucherDBContext.Certifications.Add(certification);
                return _voucherDBContext.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return false;
            }
        }

        public List<Certification> GetCertificationsOnCertType(string certType)
        {
            if (_voucherDBContext == null)
            {
                throw new InvalidOperationException("_voucherDBContext is not initialized.");
            }
            return _voucherDBContext.Certifications
              .Where(c => c.CertType == certType)
              .ToList();
        }

        public bool UpdateCreditPoints(string certCode, int credPoints)
        {
            try
            {
                var certification = _voucherDBContext.Certifications
                    .FirstOrDefault(c => c.CertCode == certCode);

                if (certification == null)
                {
                    return false;
                }

                certification.CertCreditPoints = credPoints;
                return _voucherDBContext.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return false;
            }
        }

        public bool UpdateVoucherID(int requestID)
        {
            try
            {
                var certification = _voucherDBContext.RequestDetails
                    .FirstOrDefault(c => c.RequestId == requestID);

                if (certification == null)
                {
                    return false;
                }

                var random = new Random();
                certification.VoucherId = random.Next(10000000, 99999999);
                certification.ExpiryDate = DateTime.Now.AddDays(30);

                return _voucherDBContext.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return false;
            }
        }
    }
}
