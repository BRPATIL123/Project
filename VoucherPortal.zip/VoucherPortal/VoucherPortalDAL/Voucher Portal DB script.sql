USE [master]
GO
IF (EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE ('[' + name + ']' = N'VoucherPortalDB'OR name = N'VoucherPortalDB')))
DROP DATABASE VoucherPortalDB
GO

CREATE DATABASE VoucherPortalDB
GO

USE VoucherPortalDB
GO

--DROP Scripts
IF OBJECT_ID('RequestDetails') IS NOT NULL
	DROP TABLE RequestDetails
GO

IF OBJECT_ID('Certifications') IS NOT NULL
	DROP TABLE Certifications
GO

IF OBJECT_ID('EmployeeDetails') IS NOT NULL
	DROP TABLE EmployeeDetails
GO

IF OBJECT_ID('usp_InsertVoucherRequest') IS NOT NULL
	DROP PROCEDURE usp_InsertVoucherRequest
GO

CREATE TABLE EmployeeDetails
(EmpNumber INT IDENTITY(1000,1) CONSTRAINT pk_EmpNumber PRIMARY KEY,
EmpName VARCHAR(30) NOT NULL,
CreditPoints INT CONSTRAINT chk_CreditPoints CHECK ( CreditPoints > = 0 ) DEFAULT 0)
GO

INSERT INTO EmployeeDetails VALUES('Olivia Jacob',5)
INSERT INTO EmployeeDetails VALUES('Cora Henry',9)
INSERT INTO EmployeeDetails VALUES('Eva Denial',10)
INSERT INTO EmployeeDetails VALUES('Emma Liam',15)
INSERT INTO EmployeeDetails VALUES('Liva William',5)
INSERT INTO EmployeeDetails VALUES('Jack Joe',15)
GO

CREATE TABLE Certifications(
CertCode CHAR(6) CONSTRAINT pk_CertCode PRIMARY KEY,
CertName VARCHAR(50)  NOT NULL CONSTRAINT uq_CertName UNIQUE,
CertType CHAR(1) CONSTRAINT chk_CertType CHECK (CertType in('I','E') )NOT NULL,
CertCreditPoints INT CONSTRAINT chk_CertCreditPoints CHECK (CertCreditPoints >0))
GO

INSERT INTO Certifications VALUES('EX-001','SQL Server 2008 Database developer','E',30)
INSERT INTO Certifications VALUES('EX-002','Sharepoint development','E',20)
INSERT INTO Certifications VALUES('EX-003','Programming applications in CSharp','E',20)
INSERT INTO Certifications VALUES('EX-004','Application of  Silverlight4','E',	20)
INSERT INTO Certifications VALUES('IN-001','OOP Concepts','I',12)
INSERT INTO Certifications VALUES('IN-002','Computational Problem Solving','I',12)
INSERT INTO Certifications VALUES('IN-003','Enterprise Solution Developer','I',12)
INSERT INTO Certifications VALUES('IN-004','Software Engineering Principles','I',9)
GO

CREATE TABLE RequestDetails(
RequestId INT IDENTITY(5000,1) CONSTRAINT pk_RequestID PRIMARY KEY,
EmpNumber INT CONSTRAINT fk_EmpNumber REFERENCES EmployeeDetails(EmpNumber),
DateOfRequest DATE NOT NULL DEFAULT GETDATE(),
CertCode CHAR(6) NOT NULL CONSTRAINT fk_CertCode REFERENCES Certifications(CertCode),
VoucherId BIGINT ,
ExpiryDate DATE,
Score INT CONSTRAINT chk_Score CHECK (Score>=0),
CHECK (ExpiryDate> DateOfRequest))
GO

INSERT INTO RequestDetails VALUES(1000,'30-OCT-2018','EX-001',12345678,'01-NOV-2020',	95)
INSERT INTO RequestDetails VALUES(1001,'30-NOV-2018','IN-001',23456789,'01-DEC-2020',NULL)
INSERT INTO RequestDetails VALUES(1002,'01-DEC-2018','EX-002',NULL,NULL,NULL)
INSERT INTO RequestDetails VALUES(1003,'01-DEC-2018','IN-001',NULL,NULL,NULL)
GO

CREATE PROCEDURE usp_InsertVoucherRequest
(
@EmpNumber INT,
@CertCode CHAR(6),
@RequestId INT OUT
)
AS 
BEGIN
SET @RequestId=0
	 BEGIN TRY
		IF NOT EXISTS(SELECT * FROM EmployeeDetails WHERE  EmpNumber=@EmpNumber)
			RETURN -1
		IF EXISTS(SELECT * FROM RequestDetails WHERE  EmpNumber=@EmpNumber AND CertCode=@CertCode)
			RETURN -2
		INSERT INTO RequestDetails VALUES(@EmpNumber,DEFAULT,@CertCode,NULL,NULL,NULL)
		SET @RequestId= @@IDENTITY
		RETURN 1  
	 END TRY
	 BEGIN CATCH
		RETURN -99
	 END CATCH
END
GO
---------------------------------------------------------
PRINT(1)
SELECT * FROM [RequestDetails]
PRINT(1)
SELECT * FROM [Certifications]
PRINT(1)
SELECT * FROM [EmployeeDetails]
GO
----------------------------------------------------------
