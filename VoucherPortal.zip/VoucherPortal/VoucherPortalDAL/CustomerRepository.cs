﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using VoucherPortalDataAccessLayer.Interface;
using VoucherPortalDataAccessLayer.Models;

namespace VoucherPortalDataAccessLayer
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly VoucherPortalDBContext _voucherDBContext;

        public CustomerRepository(VoucherPortalDBContext context)
        {
            _voucherDBContext = context ?? throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteRequest(int requestId)
        {
            try
            {
                var request = _voucherDBContext.RequestDetails.FirstOrDefault(r => r.RequestId == requestId);
                if (request == null) return false;

                _voucherDBContext.RequestDetails.Remove(request);
                return _voucherDBContext.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return false;
            }
        }

        public RequestDetail GetRequestDetail(int requestId)
        {
            try
            {
                return _voucherDBContext.RequestDetails.FirstOrDefault(rd => rd.RequestId == requestId);
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return null;
            }
        }

        public int InsertVoucherRequest(int empNumber, string certCode, out int requestId)
        {
            requestId = 0;
            try
            {
                // Define the parameters for the stored procedure
                var paramEmpNumber = new SqlParameter("@EmpNumber", empNumber);
                var paramCertCode = new SqlParameter("@CertCode", certCode);
                var paramRequestId = new SqlParameter("@RequestId", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                var paramReturnValue = new SqlParameter("@ReturnValue", SqlDbType.Int)
                {
                    Direction = ParameterDirection.ReturnValue
                };

                // Execute the stored procedure
                _voucherDBContext.Database.ExecuteSqlRaw(
                    "EXEC @ReturnValue = InsertVoucherRequest @EmpNumber, @CertCode, @RequestId OUTPUT",
                    paramReturnValue, paramEmpNumber, paramCertCode, paramRequestId);

                // Retrieve the output values
                requestId = (int)paramRequestId.Value;
                return (int)paramReturnValue.Value;
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return -1;
            }
        }

        public bool UpdateScore(int requestId, int score)
        {
            try
            {
                var request = _voucherDBContext.RequestDetails.FirstOrDefault(r => r.RequestId == requestId);
                if (request == null) return false;

                request.Score = score; // Assuming there is a Score field in the Request entity
                return _voucherDBContext.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                // Log the exception (not shown here)
                return false;
            }
        }
    }
}

