﻿using VoucherPortalDataAccessLayer.Models;

namespace VoucherPortalDataAccessLayer.Interface
{
    public interface IAdminRepository
    {
        bool AddCertification(Certification certification);
        List<Certification> GetCertificationsOnCertType(string certType);
        bool UpdateCreditPoints(string certCode, int credPoints);
        bool UpdateVoucherID(int requestID);
    }
}
