﻿using VoucherPortalDataAccessLayer.Models;

namespace VoucherPortalDataAccessLayer.Interface
{
    public interface ICustomerRepository
    {
        bool DeleteRequest(int requestId);
        RequestDetail GetRequestDetail(int requestId);
        int InsertVoucherRequest(int empNumber, string certCode, out int requestId);
        bool UpdateScore(int requestId, int score);
    }
}
