﻿namespace VoucherPortalDataAccessLayer.Models
{
    public partial class Certification
    {
        public Certification()
        {
            RequestDetails = new HashSet<RequestDetail>();
        }

        public string CertCode { get; set; }
        public string CertName { get; set; }
        public string CertType { get; set; }
        public int? CertCreditPoints { get; set; }

        public virtual ICollection<RequestDetail> RequestDetails { get; set; }
    }
}
