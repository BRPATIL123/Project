﻿namespace VoucherPortalDataAccessLayer.Models
{
    public partial class RequestDetail
    {
        public int RequestId { get; set; }
        public int? EmpNumber { get; set; }
        public DateTime DateOfRequest { get; set; }
        public string CertCode { get; set; }
        public long? VoucherId { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public int? Score { get; set; }

        public virtual Certification CertCodeNavigation { get; set; }
        public virtual EmployeeDetail EmpNumberNavigation { get; set; }
    }
}
