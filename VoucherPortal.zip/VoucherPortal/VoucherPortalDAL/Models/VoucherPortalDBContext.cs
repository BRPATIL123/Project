﻿using Microsoft.EntityFrameworkCore;

namespace VoucherPortalDataAccessLayer.Models
{
    public partial class VoucherPortalDBContext : DbContext
    {

        public DbSet<Certification> Certifications { get; set; }
        public DbSet<EmployeeDetail> EmployeeDetails { get; set; }
        public DbSet<RequestDetail> RequestDetails { get; set; }

        public VoucherPortalDBContext()
           : base()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=VoucherPortalDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Certification>(entity =>
            {
                entity.HasKey(e => e.CertCode)
                    .HasName("pk_CertCode");

                entity.HasIndex(e => e.CertName, "uq_CertName")
                    .IsUnique();

                entity.Property(e => e.CertCode)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CertName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CertType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<EmployeeDetail>(entity =>
            {
                entity.HasKey(e => e.EmpNumber)
                    .HasName("pk_EmpNumber");

                entity.Property(e => e.CreditPoints).HasDefaultValueSql("((0))");

                entity.Property(e => e.EmpName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RequestDetail>(entity =>
            {
                entity.HasKey(e => e.RequestId)
                    .HasName("pk_RequestID");

                entity.Property(e => e.CertCode)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DateOfRequest)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ExpiryDate).HasColumnType("date");

                entity.HasOne(d => d.CertCodeNavigation)
                    .WithMany(p => p.RequestDetails)
                    .HasForeignKey(d => d.CertCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_CertCode");

                entity.HasOne(d => d.EmpNumberNavigation)
                    .WithMany(p => p.RequestDetails)
                    .HasForeignKey(d => d.EmpNumber)
                    .HasConstraintName("fk_EmpNumber");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
