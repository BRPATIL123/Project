﻿namespace VoucherPortalDataAccessLayer.Models
{
    public partial class EmployeeDetail
    {
        public EmployeeDetail()
        {
            RequestDetails = new HashSet<RequestDetail>();
        }

        public int EmpNumber { get; set; }
        public string EmpName { get; set; }
        public int? CreditPoints { get; set; }

        public virtual ICollection<RequestDetail> RequestDetails { get; set; }
    }
}
